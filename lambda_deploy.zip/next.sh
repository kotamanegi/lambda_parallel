#!/bin/bash
chmod 777 -R /tmp
cd /tmp
/tmp/verdict.exe > /tmp/ans.txt
chmod 777 -R /tmp
