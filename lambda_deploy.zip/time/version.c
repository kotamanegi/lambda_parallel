const char *version_string = "GNU time 1.7";
